
from scipy.integrate import odeint
import numpy as np
from math import *
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter


def to_percent(temp, position):
    return '%1.0f' % (100*temp) + '%'


T = 25.0
dl = lambda l, t: ((0.2243 * T - 1.1753) / 707) * l - ((0.2243 * T - 1.1753) / 707) * l ** 2 / 707

t = np.arange(0, 5000, 1)
sol = odeint(dl, 1, t).T

DR = e**((0.0192 * T - 0.03)*log(0.2243 * T - 1.1753))
sum_ = [0]
day = [0]
flag = 0

for i in range(1, 5000, 1):
    day.append(i)
    flag += pi * (sol[0][i])**2 * 1 * DR / 12200/1000000 - 0.039/365
    sum_.append(flag)
plt.scatter(day, sum_)

plt.xlabel('time(days)', fontdict={'family': 'Times New Roman', 'size': 15})
plt.ylabel('decomposition rate', fontdict={'family': 'Times New Roman', 'size': 15})

plt.gca().yaxis.set_major_formatter(FuncFormatter(to_percent))

plt.show()

