import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

a = pd.read_excel("fungi_type.xlsx")
x0 = a.iloc[:, 0].T
y0 = a.iloc[:, 1].T
for i in range(0, 34):
    if x0[i] <= -0.16122222:
        plt.scatter(x0[i], y0[i], c='b', s=50, marker='o')
    elif x0[i] <= 0.41374604:
        plt.scatter(x0[i], y0[i], c='r', s=50, marker='+')
    else:
        plt.scatter(x0[i], y0[i], c='g', s=50, marker='*')
y0 = np.zeros(34)
X = np.vstack([x0, y0]).T

md = KMeans(n_clusters=3)
md.fit(X)

labels = 1+md.labels_
centers = md.cluster_centers_

print(labels, '\n------------\n', centers)

plt.rc('font', size=16)
for i in range(0, 34):
    if x0[i] <= -0.16122222:
        plt.scatter(x0[i], y0[i], c='b', s=50, marker='o')
    elif x0[i] <= 0.41374604:
        plt.scatter(x0[i], y0[i], c='r', s=50, marker='+')
    else:
        plt.scatter(x0[i], y0[i], c='g', s=50, marker='*')

plt.scatter(-0.712, 0, c='b', s=50, marker='o', label='Disadvantaged: -0.466')
plt.scatter(0.158, 0, c='r', s=50, marker='+', label='Moderate: 0.143')
plt.scatter(0.68371429, 0, c='g', s=50, marker='*', label='Dominant: 0.684')

plt.xlim((-1, 1))
plt.xlabel('moisture trade-off', fontdict={'family': 'Times New Roman', 'size': 15})
plt.ylabel('log(decomposition rate)', fontdict={'family': 'Times New Roman', 'size': 15})
plt.legend(prop={'family': 'Times New Roman', 'size': 13})
plt.show()
