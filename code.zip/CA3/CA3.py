import numpy as np
import matplotlib.pyplot as plt
import random
from math import *

# besides are parameters used to model different environments
x_ = 1  # 0.25 or other
y_ = 1  # 0.3 or other
z1 = 1  # 0.6 or other
z2 = 1  # 0.75 or other
z3 = 1  # 0.9 or other
sigma21 = 1  # 1.2 or other
sigma31 = 1  # 1.2 or other
sigma12 = 1  # 0.7 or other
sigma32 = 1  # 1.1 or other
sigma13 = 1  # 0.5 or other
sigma23 = 1  # 0.8 or other


def death(list_):  # to kill one random cell
    death_pos = random.choice(list_)
    list_.remove(death_pos)
    cells[death_pos[0]][death_pos[1]] = 0


def choice_one_direction(growth_pos):  # to choose one random direction(in 8 directions) to growth
    global cells
    flag = random.randint(1, 8)
    x = growth_pos[0]
    y = growth_pos[1]

    if flag == 1:
        if cells[x - 1, y - 1] != 0:
            return False
        else:
            return [x - 1, y - 1]
    elif flag == 2:
        if cells[x, y - 1] != 0:
            return False
        else:
            return [x, y - 1]
    elif flag == 3:
        if cells[x + 1, y - 1] != 0:
            return False
        else:
            return [x + 1, y - 1]
    elif flag == 4:
        if cells[x, y - 1] != 0:
            return False
        else:
            return [x, y - 1]
    elif flag == 5:
        if cells[x, y + 1] != 0:
            return False
        else:
            return [x, y + 1]
    elif flag == 6:
        if cells[x + 1, y - 1] != 0:
            return [x + 1, y - 1]
        else:
            return [x + 1, y - 1]
    elif flag == 7:
        if cells[x + 1, y] != 0:
            return [x + 1, y]
        else:
            return [x + 1, y]
    elif flag == 8:
        if cells[x + 1, y + 1] != 0:
            return False
        else:
            return [x + 1, y + 1]


def growth(list_):  # to choose one random cell to grow

    growth_pos = random.choice(list_)
    if growth_pos[0] == 0 or growth_pos[0] == w - 1 or growth_pos[1] == 0 or growth_pos[1] == h:
        return growth(list_)
    flag = choice_one_direction(growth_pos)
    if flag is False:
        return growth(list_)
    else:
        list_.append(flag)


def list_to_cells():  # put cells position into Matrix for plot
    global a, b, c, timer, cells, deposition

    deposition += (y_ * (0.002568 * len(a) + 0.001648 * len(b) + 0.001 * len(c)))  # Depositon count
    print(", A size", len(a), " B size", len(b), " C size", len(c), "Deposited:", deposition)
    for i in a:
        cells[i[0]][i[1]] = 1
    for j in b:
        cells[j[0]][j[1]] = 2
    for k in c:
        cells[k[0]][k[1]] = 3


def draw():  # to plot cells directly
    global timer, cells
    cells = np.zeros(w * h).reshape(w, h)
    list_to_cells()
    plt.title('Time:{}   A size:{}   B size:{}   C size:{}   Deposition:{}'.format(timer, len(a), len(b), len(c),
                                                                                   '%.2f' % deposition))
    if timer > 1:
        cells[0][0] = 2
    plt.imshow(cells, cmap='Greens')
    plt.show()
    if timer > 1:
        plt.pause(10)


def update_state():  # to update cells here
    global a, b, c, timer
    # below is how CA works

    num_a = int(x_ * z1 * 100000 * (
                1 / (1 + e ** (8 - 0.3 * timer)) - 1 / (1 + e ** (9 - 0.3 * timer))))  # fungi A's free growth
    num_b = int(x_ * z2 * 10000 * (
                1 / (1 + e ** (8 - 0.3 * timer)) - 1 / (1 + e ** (9 - 0.3 * timer))))  # fungi B's free growth
    num_c = int(
        x_ * z3 * 2000 * (1 / (1 + e ** (8 - 0.3 * timer)) - 1 / (1 + e ** (9 - 0.3 * timer))))  # fungi C's free growth
    num_death_a = int(
        sigma21 * 0.00000004 * len(a) * len(b) + sigma31 * 0.00000001 * len(a) * len(c))  # fungi A's death
    num_death_b = int(
        sigma12 * 0.00000003 * len(a) * len(b) + sigma32 * 0.00000001 * len(c) * len(b))  # fungi B's death
    num_death_c = int(
        sigma13 * 0.00000001 * len(a) * len(c) + sigma23 * 0.00000003 * len(b) * len(c))  # fungi C's death

    print("A growth", num_a, ",A death", num_death_a, "  B growth", num_b, ",B death", num_death_b, "  C growth", num_c,
          ",C death", num_death_c, end='')
    for _ in range(0, num_a):
        growth(a)
    for _ in range(0, num_b):
        growth(b)
    for _ in range(0, num_c):
        growth(c)
    for _ in range(0, num_death_a):
        death(a)
    if num_death_b > len(b):
        b.clear()
        draw()
    else:
        for _ in range(0, num_death_b):
            death(b)
    if num_death_c > len(c):
        c.clear()
        draw()
    else:
        for _ in range(0, num_death_c):
            death(c)

    timer += 1  # time count + 1
    list_to_cells()


def update_and_draw(times):
    global timer, a, b, c

    # plot image below
    plt.ion()
    draw()
    for _ in range(times):
        plt.title('Time:{}   A size:{}   B size:{}   C size:{}   Deposition:{}'.format(timer, len(a), len(b), len(c),
                                                                                       '%.2f' % deposition))
        plt.imshow(cells, cmap='Greens')
        update_state()
        plt.pause(1)  # pause one second before counting next time

    plt.ioff()


# initialize
w = 150  # width
h = 150  # height

deposition = 0  # deposition count
cells = np.zeros(w * h).reshape(w, h)  # vacant ground

a = [(70, 65)]  # one fungi A
b = [(70, 95)]  # one fungi B
c = [(50, 80)]  # one fungi C
timer = 0

update_and_draw(51)  # update 50 times

plt.imshow(cells, cmap='Greens')  # show pic
plt.show()
