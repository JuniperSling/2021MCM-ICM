from scipy.integrate import odeint
import numpy as np
import matplotlib.pyplot as plt
import math
from matplotlib.ticker import FuncFormatter


def to_percent(temp, position):  # change axis into percentage
    return '%1.0f' % (100*temp) + '%'


def fungi(y, t):
    T = 40
    C = 0.0192 * T - 0.03
    L = 707

    MT1 = 0.684
    MT2 = 0.143
    MT3 = -0.466
    HER1 = math.exp(0.82 / C * MT1 + 1.02 / C)
    HER2 = math.exp(0.82 / C * MT2 + 1.02 / C)
    HER3 = math.exp(0.82 / C * MT3 + 1.02 / C)
    global DR1, DR2, DR3
    DR1 = math.exp(C * math.log(HER1))
    DR2 = math.exp(C * math.log(HER2))
    DR3 = math.exp(C * math.log(HER3))

    sigma12 = 0.1
    sigma13 = 0.2
    sigma21 = 0.3
    sigma23 = 0.3
    sigma31 = 0.5
    sigma32 = 0.7

    l1, l2, l3 = y
    return np.array([HER1 / L * l1 * (1 - l1 / L - sigma12 * l2 / L - sigma13 * l3 / L), HER2 / L * l2 * (1 - l2 / L - sigma21 * l1 / L - sigma23 * l3 / L),
                     HER3 / L * l3 * (1 - l3 / L - sigma31 * l1 / L - sigma32 * l2 / L)])


t = np.arange(0, 6000, 1)  # 解方程时间范围
sol = odeint(fungi, [1, 1, 1], t)  # 三物种初始
# fungi C use axis2
fig = plt.figure()
ax1 = fig.add_subplot(111)
ax1.plot(t, sol[:, 0], 'r')
ax1.plot(t, sol[:, 1], 'b')
ax2 = ax1.twinx()
ax2.plot(t, sol[:, 2], 'g')

"""
# add  A fungi at 6000 day, use this
t1 = np.arange(6000, 10000, 1)
sol1 = odeint(fungi, [1, sol[5999][1], sol[5999][2]], t1)

plt.plot(t, sol[:, 1], 'b')
plt.plot(t, sol[:, 2], 'g')

plt.plot(t1, sol1[:, 0], 'r', label='Dominant')
plt.plot(t1, sol1[:, 1], 'b', label='Moderate')
plt.plot(t1, sol1[:, 2], 'g', label='Disadvantaged')

plt.ylim((0, 710))
plt.xlabel('time(day)', fontdict={'family': 'Times New Roman', 'size': 15})
plt.ylabel('population size', fontdict={'family': 'Times New Roman', 'size': 15})
plt.legend(loc="upper left", prop={'family': 'Times New Roman', 'size': 13})
"""

"""
# count sum of deposition  of three fungi
sum_ = [0]
day = [0]
flag = 0
for i in range(1, 6000, 1):  # sum range (days)
    day.append(i)
    flag += ((math.pi * (sol[i][0])**2 * 1 * DR1 / 12200/1000000 - 0.039/365)+(math.pi * (sol[i][1])**2 * 1 * DR2 / 12200/1000000 - 0.039/365)
             + (math.pi * (sol[i][2])**2 * 1 * DR3 / 12200/1000000 - 0.039/365))
    sum_.append(flag)
plt.plot(day, sum_)     # show sum of deposition
plt.gca().yaxis.set_major_formatter(FuncFormatter(to_percent))  # change axis into percentage
"""
plt.show()
